export async function askOnlineAI({ provider, apiKey, model, prompt, systemPrompt } = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(
      { type: "AI_REQUEST", payload: { provider, apiKey, model, prompt, systemPrompt } },
      (resp) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (resp?.error) return reject(new Error(resp.error));
        resolve(resp?.text || "");
      }
    );
  });
}

export function buildMeetingSummaryPrompt(transcript, title = "meeting transcript") {
  return `You are a precise meeting analyst.

Create a clean summary for this ${title}. Use the exact sections below:

Overview:
- 3 to 5 bullets

Decisions:
- bullets

Action Items:
- bullets with owners when named

Risks or Follow Ups:
- bullets

Transcript:
${transcript.slice(0, 12000)}`;
}

export function buildDocumentSummaryPrompt(text, label = "document") {
  return `Summarize this ${label} for someone who needs fast understanding.
Use sections:
Overview
Key points
Important details
Next questions

Content:
${text.slice(0, 12000)}`;
}

export function buildDocumentQuestionPrompt(question, context) {
  return `Answer the user question using only the context below. If the answer is missing, say that clearly.

Question: ${question}

Context:
${context.slice(0, 12000)}`;
}

export function buildChatPrompt(question, contextBlocks = []) {
  const context = contextBlocks.filter(Boolean).join("\n\n---\n\n");
  if (!context) return question;
  return `Use the context if it is relevant, otherwise answer normally.

Context:
${context.slice(0, 12000)}

User request:
${question}`;
}

export function buildQuizPrompt(text, count = 3) {
  return `Generate ${count} multiple-choice quiz questions from the content below.
Return only a JSON array shaped like:
[{"question":"...","options":["...","...","...","..."],"answer":"...","explanation":"..."}]

Content:
${text.slice(0, 8000)}`;
}
