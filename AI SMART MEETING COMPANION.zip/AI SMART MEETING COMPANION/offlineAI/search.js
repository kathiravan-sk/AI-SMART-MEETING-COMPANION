// offlineAI/search.js — Offline keyword search + answer synthesis

// Common stopwords to ignore during scoring
const STOPWORDS = new Set([
  "a","an","the","is","are","was","were","be","been","being",
  "have","has","had","do","does","did","will","would","could","should",
  "may","might","shall","can","need","dare","ought","used","to","of",
  "in","on","at","by","for","with","about","against","between","into",
  "through","during","before","after","above","below","from","up","down",
  "and","but","or","nor","so","yet","both","either","neither","not",
  "what","which","who","whom","this","that","these","those","i","me",
  "my","myself","we","our","you","your","he","she","it","they","them",
  "his","her","its","give","tell","explain","describe","list","summarize"
]);

/**
 * Tokenize text into keywords.
 */
function tokenize(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && !STOPWORDS.has(w));
}

/**
 * Score a chunk against a query using TF-style keyword overlap.
 */
function scoreChunk(chunk, queryTokens) {
  const chunkTokens = tokenize(chunk.text);
  const chunkSet = new Set(chunkTokens);
  let score = 0;
  for (const qt of queryTokens) {
    if (chunkSet.has(qt)) score += 2;
    // Partial match
    for (const ct of chunkSet) {
      if (ct.includes(qt) || qt.includes(ct)) score += 0.5;
    }
  }
  // Boost shorter, more focused chunks
  score = score / Math.log(chunkTokens.length + 2);
  return score;
}

/**
 * Retrieve top-k relevant chunks from the knowledge base.
 * @param {string} query
 * @param {Array<{id, docId, text}>} allChunks
 * @param {number} topK
 * @returns {Array<{chunk, score}>}
 */
export function retrieveChunks(query, allChunks, topK = 5) {
  const queryTokens = tokenize(query);
  if (queryTokens.length === 0) return [];

  const scored = allChunks.map((chunk) => ({
    chunk,
    score: scoreChunk(chunk, queryTokens)
  }));

  return scored
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK);
}

/**
 * Generate a local answer from retrieved chunks.
 * No LLM needed — extracts the most relevant sentences.
 */
export function generateLocalAnswer(query, retrievedChunks) {
  if (retrievedChunks.length === 0) {
    return "I am in Offline mode and could not find relevant info in your files. For general knowledge, switch to Online mode and use an API key.";
  }

  const queryTokens = new Set(tokenize(query));
  const topChunk = retrievedChunks[0].chunk;

  // Extract top sentences from the best chunk
  const sentences = topChunk.text
    .split(/(?<=[.!?])\s+/)
    .filter((s) => s.length > 20);

  // Score sentences by keyword overlap
  const scoredSentences = sentences.map((s) => {
    const tokens = tokenize(s);
    const overlap = tokens.filter((t) => queryTokens.has(t)).length;
    return { s, overlap };
  });

  scoredSentences.sort((a, b) => b.overlap - a.overlap);
  const topSentences = scoredSentences.slice(0, 3).map((x) => x.s);

  // Also include a snippet from the second best chunk if available
  let extraContext = "";
  if (retrievedChunks.length > 1) {
    const secondChunk = retrievedChunks[1].chunk.text.slice(0, 200);
    extraContext = `\n\nAdditionally: ${secondChunk}...`;
  }

  const answer = topSentences.join(" ");
  return answer
    ? `Based on your documents: ${answer}${extraContext}`
    : `Found in document: ${topChunk.text.slice(0, 300)}...`;
}

/**
 * Generate a local summary of all chunks from a document.
 */
export function generateLocalSummary(chunks) {
  if (chunks.length === 0) return "No content found in document.";

  // Take first chunk (intro), a middle chunk, and last chunk
  const total = chunks.length;
  const selected = [
    chunks[0],
    chunks[Math.floor(total / 2)],
    chunks[total - 1]
  ].filter(Boolean);

  const summaryParts = selected.map((c) => c.text.slice(0, 200).trim());
  return `📄 Document Summary (Offline):\n\n${summaryParts.join("\n\n...\n\n")}`;
}

/**
 * Generate MCQ quiz questions from chunks (offline).
 */
export function generateOfflineQuiz(chunks, count = 3) {
  const questions = [];
  const sentences = [];

  for (const chunk of chunks) {
    chunk.text.split(/(?<=[.!?])\s+/)
      .filter((s) => s.length > 40 && s.length < 200)
      .forEach((s) => sentences.push(s.trim()));
  }

  // Shuffle sentences
  sentences.sort(() => Math.random() - 0.5);

  for (let i = 0; i < Math.min(count, sentences.length); i++) {
    const sentence = sentences[i];
    const words = sentence.split(" ").filter((w) => w.length > 4);
    if (words.length < 3) continue;

    // Pick a word to blank out as the "answer"
    const answerIdx = Math.floor(Math.random() * Math.min(words.length, 6));
    const answer = words[answerIdx].replace(/[^a-zA-Z]/g, "");
    if (!answer) continue;

    const question = sentence.replace(new RegExp(`\\b${answer}\\b`, "i"), "_____");

    // Generate 3 fake options from other sentences
    const fakeOptions = sentences
      .filter((_, j) => j !== i)
      .map((s) => {
        const ws = s.split(" ").filter((w) => w.length > 4);
        return ws[Math.floor(Math.random() * ws.length)]?.replace(/[^a-zA-Z]/g, "");
      })
      .filter((w) => w && w !== answer)
      .slice(0, 3);

    if (fakeOptions.length < 3) continue;

    const options = [...fakeOptions, answer].sort(() => Math.random() - 0.5);
    questions.push({ question, options, answer, explanation: sentence });
  }

  return questions;
}
