// offlineAI/storage.js — IndexedDB wrapper for document storage

const DB_NAME = "NeuralMeetDB";
const DB_VERSION = 1;
const STORE_DOCS = "documents";
const STORE_CHUNKS = "chunks";
const STORE_SETTINGS = "settings";

let db = null;

export function openDB() {
  return new Promise((resolve, reject) => {
    if (db) return resolve(db);
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (e) => {
      const database = e.target.result;
      // Documents store: { id, name, type, text, uploadedAt }
      if (!database.objectStoreNames.contains(STORE_DOCS)) {
        database.createObjectStore(STORE_DOCS, { keyPath: "id", autoIncrement: true });
      }
      // Chunks store: { id, docId, text, start, end }
      if (!database.objectStoreNames.contains(STORE_CHUNKS)) {
        const chunksStore = database.createObjectStore(STORE_CHUNKS, { keyPath: "id", autoIncrement: true });
        chunksStore.createIndex("docId", "docId", { unique: false });
      }
      // Settings store
      if (!database.objectStoreNames.contains(STORE_SETTINGS)) {
        database.createObjectStore(STORE_SETTINGS, { keyPath: "key" });
      }
    };

    req.onsuccess = (e) => { db = e.target.result; resolve(db); };
    req.onerror = (e) => reject(e.target.error);
  });
}

// ── Documents ─────────────────────────────────────────────────────────────

export async function saveDocument(name, type, text) {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_DOCS, "readwrite");
    const store = tx.objectStore(STORE_DOCS);
    const req = store.add({ name, type, text, uploadedAt: Date.now() });
    req.onsuccess = () => resolve(req.result); // returns new docId
    req.onerror = () => reject(req.error);
  });
}

export async function getAllDocuments() {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_DOCS, "readonly");
    const req = tx.objectStore(STORE_DOCS).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function deleteDocument(docId) {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction([STORE_DOCS, STORE_CHUNKS], "readwrite");
    tx.objectStore(STORE_DOCS).delete(docId);
    // Remove associated chunks
    const chunkStore = tx.objectStore(STORE_CHUNKS);
    const idx = chunkStore.index("docId");
    const req = idx.openCursor(IDBKeyRange.only(docId));
    req.onsuccess = (e) => {
      const cursor = e.target.result;
      if (cursor) { cursor.delete(); cursor.continue(); }
    };
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

// ── Chunks ────────────────────────────────────────────────────────────────

export async function saveChunks(docId, chunks) {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_CHUNKS, "readwrite");
    const store = tx.objectStore(STORE_CHUNKS);
    chunks.forEach((chunk) => store.add({ ...chunk, docId }));
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

export async function getChunksForDoc(docId) {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_CHUNKS, "readonly");
    const store = tx.objectStore(STORE_CHUNKS);
    const idx = store.index("docId");
    const req = idx.getAll(IDBKeyRange.only(docId));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function getAllChunks() {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_CHUNKS, "readonly");
    const req = tx.objectStore(STORE_CHUNKS).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// ── Settings ──────────────────────────────────────────────────────────────

export async function saveSetting(key, value) {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_SETTINGS, "readwrite");
    tx.objectStore(STORE_SETTINGS).put({ key, value });
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

export async function getSetting(key) {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_SETTINGS, "readonly");
    const req = tx.objectStore(STORE_SETTINGS).get(key);
    req.onsuccess = () => resolve(req.result?.value ?? null);
    req.onerror = () => reject(req.error);
  });
}
