// offlineAI/chunking.js — Splits document text into searchable chunks

/**
 * Split text into overlapping chunks for better retrieval.
 * @param {string} text - Full document text
 * @param {number} chunkSize - Characters per chunk (default 400)
 * @param {number} overlap - Overlap between chunks (default 80)
 * @returns {Array<{id, text, start, end}>}
 */
export function chunkText(text, chunkSize = 400, overlap = 80) {
  const chunks = [];
  let start = 0;
  let id = 0;

  // Normalize whitespace
  text = text.replace(/\s+/g, " ").trim();

  while (start < text.length) {
    const end = Math.min(start + chunkSize, text.length);
    chunks.push({ id: id++, text: text.slice(start, end).trim(), start, end });
    start += chunkSize - overlap;
    if (start >= text.length) break;
  }

  return chunks;
}

/**
 * Extract sentences from text for finer-grained retrieval.
 */
export function extractSentences(text) {
  return text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?])\s+/)
    .filter((s) => s.length > 20)
    .map((s, i) => ({ id: i, text: s.trim() }));
}
