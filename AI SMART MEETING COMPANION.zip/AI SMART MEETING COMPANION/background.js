chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

chrome.runtime.onInstalled.addListener(() => {
  const menuItems = [
    { id: "nm-ask-ai", title: "Ask NeuralMeet", contexts: ["selection"] },
    { id: "nm-summarize-page", title: "Summarize this page", contexts: ["page"] }
  ];

  for (const item of menuItems) {
    chrome.contextMenus.create(item);
  }
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  chrome.sidePanel.open({ tabId: tab.id }, () => {
    chrome.runtime.sendMessage({
      type: "CONTEXT_ACTION",
      action: info.menuItemId,
      text: info.selectionText || ""
    });
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if ((message.type === "TRANSCRIPT_UPDATE" || message.type === "MEETING_STATUS" || message.type === "OPEN_TAB") && !message.__relay) {
    chrome.runtime.sendMessage({ ...message, __relay: true });
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === "APPEND_NOTE") {
    chrome.storage.local.get("nm_notes", (res) => {
      const existing = res.nm_notes || "";
      chrome.storage.local.set({ nm_notes: `${existing}${message.text}`.trim() });
      chrome.runtime.sendMessage({ type: "NOTE_APPENDED" });
    });
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === "AI_REQUEST") {
    handleAIRequest(message.payload)
      .then(sendResponse)
      .catch((err) => sendResponse({ error: err.message }));
    return true;
  }

  if (message.type === "GET_PAGE_TEXT") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTab = tabs[0];
      if (!activeTab?.id) {
        sendResponse({ text: "", title: "", url: "" });
        return;
      }

      chrome.tabs.sendMessage(activeTab.id, { type: "EXTRACT_PAGE_TEXT" }, (resp) => {
        if (chrome.runtime.lastError) {
          sendResponse({ text: "", title: activeTab.title || "", url: activeTab.url || "" });
          return;
        }
        sendResponse(resp || { text: "", title: "", url: "" });
      });
    });
    return true;
  }

  if (message.type === "TTS_SPEAK") {
    chrome.tts.stop();
    chrome.tts.speak(message.text, {
      rate: message.rate || 1,
      onEvent: (event) => {
        if (event.type === "end" || event.type === "error") {
          chrome.runtime.sendMessage({ type: "TTS_DONE" });
        }
      }
    });
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === "TTS_STOP") {
    chrome.tts.stop();
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === "AUDIO_TRANSCRIBE") {
    transcribeAudio(message.payload)
      .then(sendResponse)
      .catch((err) => sendResponse({ error: err.message }));
    return true;
  }

  sendResponse({ ok: true });
  return true;
});

async function handleAIRequest({ provider, apiKey, model, prompt, systemPrompt }) {
  if (!apiKey) throw new Error("Missing API key.");
  if (provider === "openai") return callOpenAI(apiKey, model || "gpt-4o-mini", prompt, systemPrompt);
  if (provider === "gemini") return callGemini(apiKey, model || "gemini-2.0-flash", prompt, systemPrompt);
  throw new Error(`Unknown provider: ${provider}`);
}

async function callOpenAI(apiKey, model, prompt, systemPrompt) {
  const messages = [];
  if (systemPrompt) messages.push({ role: "system", content: systemPrompt });
  messages.push({ role: "user", content: prompt });

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model,
      messages,
      max_tokens: 1800
    })
  });

  if (!response.ok) {
    throw new Error(`OpenAI request failed: ${response.status}`);
  }

  const data = await response.json();
  return { text: data.choices?.[0]?.message?.content || "" };
}

async function callGemini(apiKey, model, prompt, systemPrompt) {
  const fullPrompt = systemPrompt
    ? `System instructions:\n${systemPrompt}\n\nUser prompt:\n${prompt}`
    : prompt;

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: fullPrompt }] }]
      })
    }
  );

  if (!response.ok) {
    throw new Error(`Gemini request failed: ${response.status}`);
  }

  const data = await response.json();
  return { text: data.candidates?.[0]?.content?.parts?.[0]?.text || "" };
}

async function transcribeAudio({ provider, apiKey, model, fileName, mimeType, arrayBuffer, language }) {
  if (provider !== "openai") {
    throw new Error("Media transcription currently requires OpenAI.");
  }
  if (!apiKey) {
    throw new Error("Add an OpenAI API key in Settings first.");
  }
  if (!arrayBuffer) {
    throw new Error("Missing audio or video data.");
  }

  const size = arrayBuffer.byteLength;
  const maxSize = 25 * 1024 * 1024;
  if (size > maxSize) {
    throw new Error("This file is larger than 25 MB. Use a smaller clip.");
  }

  const blob = new Blob([arrayBuffer], { type: mimeType || "application/octet-stream" });
  const formData = new FormData();
  formData.append("file", blob, fileName || "media-upload");
  formData.append("model", model || "gpt-4o-mini-transcribe");
  if (language) formData.append("language", language);

  const response = await fetch("https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`
    },
    body: formData
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Transcription failed: ${response.status} ${errorText.slice(0, 200)}`);
  }

  const data = await response.json();
  return { text: data.text || "" };
}
