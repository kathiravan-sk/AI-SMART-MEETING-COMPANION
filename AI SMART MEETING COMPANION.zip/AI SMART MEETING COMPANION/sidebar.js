import { extractTextFromFile } from "./fileHandler/index.js";
import { chunkText } from "./offlineAI/chunking.js";
import {
  openDB,
  saveDocument,
  getAllDocuments,
  deleteDocument,
  saveChunks,
  getChunksForDoc,
  getAllChunks,
  saveSetting,
  getSetting
} from "./offlineAI/storage.js";
import {
  retrieveChunks,
  generateLocalAnswer,
  generateLocalSummary,
  generateOfflineQuiz
} from "./offlineAI/search.js";
import {
  askOnlineAI,
  buildMeetingSummaryPrompt,
  buildDocumentSummaryPrompt,
  buildDocumentQuestionPrompt,
  buildChatPrompt,
  buildQuizPrompt
} from "./ai/api.js";

if (window.pdfjsLib) {
  window.pdfjsLib.GlobalWorkerOptions.workerSrc = "lib/pdf.worker.min.js";
}

const $ = (id) => document.getElementById(id);

const state = {
  isCapturing: false,
  transcript: [],
  meetingSummary: "",
  mediaTranscript: "",
  mediaSummary: "",
  mediaFile: null,
  documents: [],
  selectedDocId: null,
  notes: "",
  pageText: "",
  pageTitle: "",
  settings: {
    provider: "gemini",
    apiKey: "AIzaSyCpL0QS2-lvzrjK7q_2TXW3MJ_NePfLbNI",
    model: "gemini-2.0-flash",
    transcriptionModel: "gpt-4o-mini-transcribe",
    autoSummary: true
  }
};

let meetingSummaryTimer = null;

async function init() {
  await openDB();
  await loadSettings();
  await loadDocuments();
  loadNotes();
  await loadMeetingSession();
  await loadMediaSession();
  setupTabs();
  setupSettings();
  setupMeeting();
  setupMedia();
  setupDocs();
  setupChat();
  setupNotes();
  listenForMessages();
  syncSettingsUI();
  renderDocuments();
  renderMeetingState();
  renderMediaState();
  updateDashboard();
  ensureHelperOnActiveTab().catch(() => {});
}

function setupTabs() {
  document.querySelectorAll(".tab-btn").forEach((button) => {
    button.addEventListener("click", () => switchTab(button.dataset.tab));
  });

  document.querySelectorAll("[data-tab-target]").forEach((button) => {
    button.addEventListener("click", () => switchTab(button.dataset.tabTarget));
  });
}

function switchTab(tab) {
  document.querySelectorAll(".tab-btn").forEach((button) => {
    button.classList.toggle("active", button.dataset.tab === tab);
  });
  document.querySelectorAll(".panel").forEach((panel) => {
    panel.classList.toggle("active", panel.id === `panel-${tab}`);
  });
}

async function loadSettings() {
  state.settings.provider = (await getSetting("provider")) || "gemini";
  state.settings.apiKey = (await getSetting("apiKey")) || "AIzaSyCpL0QS2-lvzrjK7q_2TXW3MJ_NePfLbNI";
  state.settings.model = (await getSetting("model")) || "gemini-2.0-flash";
  state.settings.transcriptionModel = (await getSetting("transcriptionModel")) || "gpt-4o-mini-transcribe";
  state.settings.autoSummary = ((await getSetting("autoSummary")) || "true") === "true";
}

function syncSettingsUI() {
  $("providerSelect").value = state.settings.provider;
  $("apiKeyInput").value = state.settings.apiKey;
  $("modelInput").value = state.settings.model;
  $("transcriptionModelInput").value = state.settings.transcriptionModel;
  $("autoSummaryToggle").checked = state.settings.autoSummary;
  $("modeLabel").textContent = state.settings.apiKey ? "Online" : "Offline";
  $("providerBadge").textContent = state.settings.provider === "openai" ? "OpenAI" : "Gemini";
  $("autoSummaryLabel").textContent = state.settings.autoSummary ? "On" : "Off";
  $("transcriptionModelLabel").textContent = state.settings.transcriptionModel;
}

function setupSettings() {
  $("settingsBtn").addEventListener("click", () => $("settingsModal").classList.remove("hidden"));
  $("closeSettingsBtn").addEventListener("click", () => $("settingsModal").classList.add("hidden"));
  $("settingsModal").addEventListener("click", (event) => {
    if (event.target === $("settingsModal")) {
      $("settingsModal").classList.add("hidden");
    }
  });

  $("saveSettingsBtn").addEventListener("click", async () => {
    state.settings.provider = $("providerSelect").value;
    state.settings.apiKey = $("apiKeyInput").value.trim();
    state.settings.model = $("modelInput").value.trim() || "gpt-4o-mini";
    state.settings.transcriptionModel = $("transcriptionModelInput").value.trim() || "gpt-4o-mini-transcribe";
    state.settings.autoSummary = $("autoSummaryToggle").checked;

    await saveSetting("provider", state.settings.provider);
    await saveSetting("apiKey", state.settings.apiKey);
    await saveSetting("model", state.settings.model);
    await saveSetting("transcriptionModel", state.settings.transcriptionModel);
    await saveSetting("autoSummary", String(state.settings.autoSummary));

    syncSettingsUI();
    $("settingsModal").classList.add("hidden");
    toast("Settings saved.");
  });
}

function setupMeeting() {
  $("toggleCaptureBtn").addEventListener("click", toggleCapture);
  $("summarizeMeetingBtn").addEventListener("click", () => summarizeMeeting(true));
  $("clearTranscriptBtn").addEventListener("click", clearTranscript);
  $("saveMeetingSummaryBtn").addEventListener("click", () => {
    if (!state.meetingSummary) {
      toast("No meeting summary yet.");
      return;
    }
    appendToNotes(`\n\nMeeting summary\n${state.meetingSummary}`);
    toast("Meeting summary added to notes.");
  });
}

function setupMedia() {
  $("pickMediaBtn").addEventListener("click", () => $("mediaInput").click());
  $("mediaInput").addEventListener("change", (event) => {
    const file = event.target.files?.[0];
    if (file) processMediaFile(file);
  });
  $("copyMediaTranscriptBtn").addEventListener("click", async () => {
    const text = $("mediaTranscript").value.trim();
    if (!text) return;
    await navigator.clipboard.writeText(text);
    toast("Transcript copied.");
  });
  $("saveMediaTranscriptBtn").addEventListener("click", saveMediaTranscriptAsDocument);

  const zone = $("mediaDropzone");
  zone.addEventListener("dragover", (event) => {
    event.preventDefault();
    zone.classList.add("drag-over");
  });
  zone.addEventListener("dragleave", () => zone.classList.remove("drag-over"));
  zone.addEventListener("drop", (event) => {
    event.preventDefault();
    zone.classList.remove("drag-over");
    const file = event.dataTransfer.files?.[0];
    if (file) processMediaFile(file);
  });
}

function setupDocs() {
  $("pickDocBtn").addEventListener("click", () => $("fileInput").click());
  $("fileInput").addEventListener("change", (event) => handleDocumentFiles(event.target.files));

  const zone = $("uploadZone");
  zone.addEventListener("dragover", (event) => {
    event.preventDefault();
    zone.classList.add("drag-over");
  });
  zone.addEventListener("dragleave", () => zone.classList.remove("drag-over"));
  zone.addEventListener("drop", (event) => {
    event.preventDefault();
    zone.classList.remove("drag-over");
    handleDocumentFiles(event.dataTransfer.files);
  });

  $("summarizeDocBtn").addEventListener("click", summarizeSelectedDoc);
  $("searchDocBtn").addEventListener("click", askAboutSelectedDoc);
  $("generateDocQuizBtn").addEventListener("click", generateDocQuizFromSelected);
  $("readDocBtn").addEventListener("click", readSelectedDocAloud);
  $("saveWisebaseBtn").addEventListener("click", saveSelectedDocToNotes);
}

function setupChat() {
  $("sendBtn").addEventListener("click", sendChatMessage);
  $("clearChatBtn").addEventListener("click", () => {
    $("chatMessages").innerHTML = '<div class="empty-state">Ask for action items, decisions, summaries, or a document answer.</div>';
  });
  $("chatInput").addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      sendChatMessage();
    }
  });
}

function setupNotes() {
  $("saveNotesBtn").addEventListener("click", saveNotes);
  $("insertMeetingIntoNotesBtn").addEventListener("click", () => {
    if (!state.meetingSummary) {
      toast("No meeting summary yet.");
      return;
    }
    appendToNotes(`\n\nMeeting summary\n${state.meetingSummary}`);
  });
  $("notesArea").addEventListener("input", debounce(saveNotes, 1200));
}

function listenForMessages() {
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "TRANSCRIPT_UPDATE" && message.data?.text) {
      addTranscriptEntry(message.data);
    }

    if (message.type === "MEETING_STATUS") {
      const { active, platform } = message.data || {};
      state.isCapturing = Boolean(active);
      setCaptureStatus(active ? `Capturing ${platform || ""}`.trim() : "Ready", Boolean(active));
      $("meetingPlatform").textContent = platform ? `Detected ${platform}` : "Open Meet, Zoom, or a captioned video tab";
      $("toggleCaptureBtn").textContent = active ? "Stop capture" : "Start capture";

      if (!active && state.settings.autoSummary && state.transcript.length >= 4) {
        summarizeMeeting(false);
      }
    }

    if (message.type === "OPEN_TAB" && message.tab) {
      switchTab(message.tab);
    }

    if (message.type === "CONTEXT_ACTION") {
      handleContextAction(message);
    }

    if (message.type === "NOTE_APPENDED") {
      loadNotes();
    }
  });
}

function setCaptureStatus(text, live) {
  $("captureStatusText").textContent = text;
  $("captureStatusDot").classList.toggle("live", live);
}

function toggleCapture() {
  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    const activeTab = tabs[0];
    if (!activeTab?.id) {
      toast("No active tab found.");
      return;
    }
    await ensureHelperOnTab(activeTab.id);
    const type = state.isCapturing ? "STOP_CAPTURE" : "START_CAPTURE";
    chrome.tabs.sendMessage(activeTab.id, { type }, () => {
      if (chrome.runtime.lastError) {
        toast("Could not talk to this tab. Refresh the page once and try again.");
      }
    });
    state.isCapturing = !state.isCapturing;
    $("toggleCaptureBtn").textContent = state.isCapturing ? "Stop capture" : "Start capture";
    setCaptureStatus(state.isCapturing ? "Waiting for captions" : "Ready", state.isCapturing);
  });
}

function clearTranscript() {
  state.transcript = [];
  state.meetingSummary = "";
  renderMeetingState();
  persistMeetingSession();
  updateDashboard();
  updateTranscriptMeta();
}

function addTranscriptEntry(entry) {
  const duplicate = state.transcript[state.transcript.length - 1]?.text === entry.text;
  if (duplicate) return;

  state.transcript.push({
    text: entry.text.trim(),
    time: entry.time || new Date().toLocaleTimeString()
  });
  renderTranscriptEntries();
  persistMeetingSession();
  updateTranscriptMeta();
  updateDashboard();

  if (state.settings.autoSummary) {
    clearTimeout(meetingSummaryTimer);
    meetingSummaryTimer = setTimeout(() => summarizeMeeting(false), 2200);
  }
}

function updateTranscriptMeta() {
  const count = state.transcript.length;
  $("transcriptMeta").textContent = count ? `${count} transcript lines captured` : "No transcript yet";
}

async function summarizeMeeting(force) {
  if (state.transcript.length < 4) {
    if (force) toast("Need a little more transcript first.");
    return;
  }

  const transcriptText = state.transcript.map((item) => item.text).join(" ");
  const offlineSummary = buildOfflineMeetingSummary(transcriptText);

  if (!state.settings.apiKey) {
    state.meetingSummary = offlineSummary;
    renderMeetingState();
    persistMeetingSession();
    updateDashboard();
    return;
  }

  showLoading("Summarizing meeting...");
  try {
    const summary = await askOnlineAI({
      ...state.settings,
      prompt: buildMeetingSummaryPrompt(transcriptText),
      systemPrompt: "You turn transcripts into organized notes without adding made-up facts."
    });
    state.meetingSummary = summary || offlineSummary;
    renderMeetingState();
    persistMeetingSession();
    updateDashboard();
  } catch (error) {
    state.meetingSummary = offlineSummary;
    renderMeetingState();
    persistMeetingSession();
    toast(error.message);
  } finally {
    hideLoading();
  }
}

function buildOfflineMeetingSummary(text) {
  const chunks = chunkText(text).map((chunk, index) => ({ ...chunk, id: index, docId: "meeting" }));
  const fallback = generateLocalSummary(chunks);
  const keyTerms = extractKeyTerms(text).join(", ") || "No strong keywords yet";
  return `Overview\n${fallback}\n\nKey terms\n${keyTerms}`;
}

async function processMediaFile(file) {
  state.mediaFile = file;
  $("mediaFileName").textContent = file.name;
  $("mediaFileSize").textContent = formatFileSize(file.size);
  $("mediaJobMeta").textContent = "Uploading for transcription";

  if (!state.settings.apiKey) {
    toast("Add an API key in Settings to transcribe media.");
    switchTab("media");
    return;
  }

  if (state.settings.provider !== "openai") {
    $("mediaJobMeta").textContent = "OpenAI key required for transcription";
    toast("This connected key is for Gemini. Media transcription still requires an OpenAI API key.");
    switchTab("media");
    return;
  }

  showLoading("Transcribing media...");
  try {
    const arrayBuffer = await file.arrayBuffer();
    const response = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        {
          type: "AUDIO_TRANSCRIBE",
          payload: {
            provider: state.settings.provider,
            apiKey: state.settings.apiKey,
            model: state.settings.transcriptionModel,
            fileName: file.name,
            mimeType: file.type,
            arrayBuffer,
            language: "en"
          }
        },
        (result) => {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          if (result?.error) return reject(new Error(result.error));
          resolve(result);
        }
      );
    });

    state.mediaTranscript = response.text || "";
    $("mediaJobMeta").textContent = "Transcript ready";
    renderMediaState();
    persistMediaSession();
    await summarizeMediaTranscript();
    toast("Media transcription complete.");
  } catch (error) {
    $("mediaJobMeta").textContent = "Transcription failed";
    toast(error.message);
  } finally {
    hideLoading();
  }
}

async function summarizeMediaTranscript() {
  const text = state.mediaTranscript.trim();
  if (!text) return;

  const fallback = buildOfflineMeetingSummary(text);

  if (!state.settings.apiKey) {
    state.mediaSummary = fallback;
    renderMediaState();
    persistMediaSession();
    updateDashboard();
    return;
  }

  try {
    const summary = await askOnlineAI({
      ...state.settings,
      prompt: buildMeetingSummaryPrompt(text, "media transcript"),
      systemPrompt: "Summarize recorded media into clean notes and action items."
    });
    state.mediaSummary = summary || fallback;
    renderMediaState();
  } catch (error) {
    state.mediaSummary = fallback;
    renderMediaState();
    toast(error.message);
  }

  persistMediaSession();
  updateDashboard();
}

async function saveMediaTranscriptAsDocument() {
  if (!state.mediaTranscript.trim()) {
    toast("No media transcript to save.");
    return;
  }

  const name = state.mediaFile ? `${state.mediaFile.name} transcript.txt` : `media-transcript-${Date.now()}.txt`;
  const docId = await saveDocument(name, "text/plain", state.mediaTranscript);
  await saveChunks(docId, chunkText(state.mediaTranscript));
  await loadDocuments();
  toast("Transcript saved to documents.");
}

async function loadMeetingSession() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["nm_meeting_transcript", "nm_meeting_summary"], (res) => {
      state.transcript = Array.isArray(res.nm_meeting_transcript) ? res.nm_meeting_transcript : [];
      state.meetingSummary = res.nm_meeting_summary || "";
      resolve();
    });
  });
}

function persistMeetingSession() {
  chrome.storage.local.set({
    nm_meeting_transcript: state.transcript,
    nm_meeting_summary: state.meetingSummary
  });
}

async function loadMediaSession() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["nm_media_transcript", "nm_media_summary"], (res) => {
      state.mediaTranscript = res.nm_media_transcript || "";
      state.mediaSummary = res.nm_media_summary || "";
      resolve();
    });
  });
}

function persistMediaSession() {
  chrome.storage.local.set({
    nm_media_transcript: state.mediaTranscript,
    nm_media_summary: state.mediaSummary
  });
}

function renderMeetingState() {
  $("meetingSummary").textContent = state.meetingSummary || "Summary will appear automatically when enough transcript arrives.";
  renderTranscriptEntries();
  updateTranscriptMeta();
}

function renderTranscriptEntries() {
  const box = $("transcriptBox");
  box.innerHTML = "";

  if (!state.transcript.length) {
    box.innerHTML = '<div class="empty-state small">Waiting for captions from the current tab.</div>';
    return;
  }

  state.transcript.forEach((entry) => {
    const row = document.createElement("div");
    row.className = "transcript-entry";
    row.innerHTML = `<span class="transcript-time">${escapeHtml(entry.time || "")}</span><div>${escapeHtml(entry.text)}</div>`;
    box.appendChild(row);
  });
  box.scrollTop = box.scrollHeight;
}

function renderMediaState() {
  $("mediaTranscript").value = state.mediaTranscript || "";
  $("mediaSummary").textContent = state.mediaSummary || "Upload a file to generate transcript text and a summary.";
}

async function handleDocumentFiles(fileList) {
  const files = Array.from(fileList || []);
  for (const file of files) {
    showLoading(`Reading ${file.name}...`);
    try {
      const text = await extractTextFromFile(file);
      const docId = await saveDocument(file.name, file.type, text);
      await saveChunks(docId, chunkText(text));
      toast(`${file.name} added.`);
    } catch (error) {
      toast(`${file.name}: ${error.message}`);
    } finally {
      hideLoading();
    }
  }

  await loadDocuments();
}

async function loadDocuments() {
  state.documents = await getAllDocuments();
  updateDashboard();
  renderDocuments();
}

function renderDocuments() {
  const list = $("docList");
  list.innerHTML = "";

  if (!state.documents.length) {
    list.innerHTML = '<div class="empty-state small">Upload a document or save a media transcript here.</div>';
    return;
  }

  state.documents.forEach((doc) => {
    const item = document.createElement("button");
    item.type = "button";
    item.className = `doc-item${state.selectedDocId === doc.id ? " selected" : ""}`;
    item.innerHTML = `
      <div style="text-align:left">
        <strong>${escapeHtml(doc.name)}</strong>
        <div class="doc-meta">${Math.round((doc.text?.length || 0) / 1000)}k chars</div>
      </div>
      <span class="text-btn" data-delete="${doc.id}">Delete</span>
    `;

    item.addEventListener("click", async (event) => {
      const deleteId = event.target.dataset.delete;
      if (deleteId) {
        await deleteDocument(Number(deleteId));
        if (state.selectedDocId === Number(deleteId)) {
          state.selectedDocId = null;
        }
        await loadDocuments();
        return;
      }

      state.selectedDocId = doc.id;
      renderDocuments();
      $("docResult").textContent = doc.text.slice(0, 1200);
    });

    list.appendChild(item);
  });
}

async function summarizeSelectedDoc() {
  const doc = getSelectedDoc();
  if (!doc) {
    toast("Select a document first.");
    return;
  }

  const fallback = generateLocalSummary(await getChunksForDoc(doc.id));

  if (!state.settings.apiKey) {
    $("docResult").textContent = fallback;
    return;
  }

  showLoading("Summarizing document...");
  try {
    const result = await askOnlineAI({
      ...state.settings,
      prompt: buildDocumentSummaryPrompt(doc.text, doc.name),
      systemPrompt: "Summaries should be easy to scan and faithful to the source."
    });
    $("docResult").textContent = result || fallback;
  } catch (error) {
    $("docResult").textContent = fallback;
    toast(error.message);
  } finally {
    hideLoading();
  }
}

async function askAboutSelectedDoc() {
  const doc = getSelectedDoc();
  if (!doc) {
    toast("Select a document first.");
    return;
  }

  const question = window.prompt("What do you want to ask about this document?");
  if (!question) return;

  const chunks = await getChunksForDoc(doc.id);
  const relevant = retrieveChunks(question, chunks, 5);
  const fallback = generateLocalAnswer(question, relevant);

  if (!state.settings.apiKey) {
    $("docResult").textContent = fallback;
    return;
  }

  showLoading("Searching document...");
  try {
    const context = relevant.map((item) => item.chunk.text).join("\n\n");
    const result = await askOnlineAI({
      ...state.settings,
      prompt: buildDocumentQuestionPrompt(question, context),
      systemPrompt: "Answer only from the provided context."
    });
    $("docResult").textContent = result || fallback;
  } catch (error) {
    $("docResult").textContent = fallback;
    toast(error.message);
  } finally {
    hideLoading();
  }
}

async function generateDocQuizFromSelected() {
  const doc = getSelectedDoc();
  if (!doc) {
    toast("Select a document first.");
    return;
  }

  showLoading("Generating quiz...");
  try {
    let questions;
    if (state.settings.apiKey) {
      const raw = await askOnlineAI({
        ...state.settings,
        prompt: buildQuizPrompt(doc.text, 3),
        systemPrompt: "Return only valid JSON."
      });
      questions = parseQuiz(raw);
    } else {
      questions = generateOfflineQuiz(await getChunksForDoc(doc.id), 3);
    }

    const summary = questions.map((item, index) => {
      const options = item.options.map((option) => `- ${option}`).join("\n");
      return `Q${index + 1}. ${item.question}\n${options}\nAnswer: ${item.answer}`;
    }).join("\n\n");

    $("docResult").textContent = summary || "Could not generate quiz questions.";
  } catch (error) {
    toast(error.message);
  } finally {
    hideLoading();
  }
}

function readSelectedDocAloud() {
  const doc = getSelectedDoc();
  if (!doc) {
    toast("Select a document first.");
    return;
  }
  chrome.runtime.sendMessage({ type: "TTS_SPEAK", text: doc.text.slice(0, 3500), rate: 1 });
}

function saveSelectedDocToNotes() {
  const doc = getSelectedDoc();
  if (!doc) {
    toast("Select a document first.");
    return;
  }
  appendToNotes(`\n\n${doc.name}\n${doc.text.slice(0, 1800)}`);
}

function getSelectedDoc() {
  return state.documents.find((doc) => doc.id === state.selectedDocId);
}

async function sendChatMessage() {
  const input = $("chatInput");
  const text = input.value.trim();
  if (!text) return;

  appendChat("user", text);
  input.value = "";

  const contextMode = $("chatContextSelect").value;
  const contextBlocks = await buildChatContext(text, contextMode);

  if (!state.settings.apiKey) {
    const offlineAnswer = await buildOfflineChatAnswer(text, contextBlocks);
    appendChat("ai", offlineAnswer);
    return;
  }

  showLoading("Thinking...");
  try {
    const answer = await askOnlineAI({
      ...state.settings,
      prompt: buildChatPrompt(text, contextBlocks),
      systemPrompt: "Be concise, helpful, and clearly structured."
    });
    appendChat("ai", answer || "No response returned.");
  } catch (error) {
    appendChat("ai", error.message);
  } finally {
    hideLoading();
  }
}

async function buildChatContext(question, mode) {
  const blocks = [];

  if (mode === "general") return blocks;

  if ((mode === "auto" || mode === "meeting") && state.transcript.length) {
    blocks.push(`Meeting transcript:\n${state.transcript.slice(-80).map((item) => item.text).join(" ")}`);
  }

  if ((mode === "auto" || mode === "media") && state.mediaTranscript) {
    blocks.push(`Media transcript:\n${state.mediaTranscript.slice(0, 5000)}`);
  }

  if (mode === "auto" || mode === "docs") {
    const chunks = await getAllChunks();
    const relevant = retrieveChunks(question, chunks, 4);
    if (relevant.length) {
      blocks.push(`Document context:\n${relevant.map((item) => item.chunk.text).join("\n\n")}`);
    }
  }

  return blocks;
}

async function buildOfflineChatAnswer(question, contextBlocks) {
  const chunks = [];

  contextBlocks.forEach((text, index) => {
    chunks.push({ id: index, docId: `context-${index}`, text });
  });

  if (!chunks.length) {
    return "No local context found. Add an API key for general AI answers, or upload documents and transcripts first.";
  }

  const relevant = retrieveChunks(question, chunks, 4);
  return generateLocalAnswer(question, relevant);
}

function appendChat(role, text) {
  const thread = $("chatMessages");
  thread.querySelector(".empty-state")?.remove();
  const message = document.createElement("div");
  message.className = `chat-message ${role}`;
  message.textContent = text;
  thread.appendChild(message);
  thread.scrollTop = thread.scrollHeight;
}

async function handleContextAction(message) {
  if (message.action === "nm-summarize-page") {
    const page = await readCurrentPage();
    if (!page.text) {
      toast("Could not read this page.");
      return;
    }
    switchTab("ask");
    $("chatInput").value = `Summarize this page:\n\n${page.text.slice(0, 5000)}`;
    sendChatMessage();
    return;
  }

  if (message.action === "nm-ask-ai" && message.text) {
    switchTab("ask");
    $("chatInput").value = message.text;
    sendChatMessage();
  }
}

async function readCurrentPage() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const activeTab = tabs[0];
      if (!activeTab?.id) {
        resolve({ text: "", title: "", url: "" });
        return;
      }

      await ensureHelperOnTab(activeTab.id);
      chrome.runtime.sendMessage({ type: "GET_PAGE_TEXT" }, (response) => {
        state.pageText = response?.text || "";
        state.pageTitle = response?.title || "";
        resolve(response || { text: "", title: "", url: "" });
      });
    });
  });
}

async function ensureHelperOnActiveTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const activeTab = tabs[0];
      if (!activeTab?.id) {
        resolve();
        return;
      }
      await ensureHelperOnTab(activeTab.id);
      resolve();
    });
  });
}

async function ensureHelperOnTab(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
  } catch {
    // Content script may already exist or the page may not allow injection.
  }
}

function loadNotes() {
  chrome.storage.local.get("nm_notes", (res) => {
    state.notes = res.nm_notes || "";
    $("notesArea").value = state.notes;
  });
}

function saveNotes() {
  state.notes = $("notesArea").value;
  chrome.storage.local.set({ nm_notes: state.notes });
}

function appendToNotes(text) {
  const current = $("notesArea").value.trim();
  $("notesArea").value = `${current ? `${current}\n` : ""}${text.trim()}\n`;
  saveNotes();
}

function updateDashboard() {
  $("metricTranscriptCount").textContent = String(state.transcript.length);
  $("metricDocumentCount").textContent = String(state.documents.length);
  $("metricSummaryState").textContent = state.meetingSummary || state.mediaSummary ? "Ready" : "Waiting";
}

function showLoading(text) {
  $("loadingText").textContent = text;
  $("loadingOverlay").classList.remove("hidden");
}

function hideLoading() {
  $("loadingOverlay").classList.add("hidden");
}

function toast(message) {
  const node = document.createElement("div");
  node.className = "toast";
  node.textContent = message;
  $("toastLayer").appendChild(node);
  setTimeout(() => node.remove(), 2800);
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function debounce(fn, delay) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

function extractKeyTerms(text) {
  const stop = new Set(["this", "that", "with", "from", "were", "have", "about", "there", "their", "would"]);
  const counts = {};
  text.toLowerCase().split(/\W+/).forEach((word) => {
    if (word.length < 5 || stop.has(word)) return;
    counts[word] = (counts[word] || 0) + 1;
  });
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([word]) => word);
}

function formatFileSize(size) {
  if (!size) return "0 B";
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function parseQuiz(raw) {
  try {
    return JSON.parse(raw.replace(/```json|```/g, "").trim());
  } catch {
    const match = raw.match(/\[[\s\S]*\]/);
    return match ? JSON.parse(match[0]) : [];
  }
}

init().catch((error) => {
  console.error(error);
  toast(error.message || "Failed to load extension UI.");
});
