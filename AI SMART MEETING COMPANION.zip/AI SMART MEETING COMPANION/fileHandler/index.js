// fileHandler/index.js — Unified file text extraction

/**
 * Extract text from an uploaded file.
 * Dispatches to the correct parser based on MIME type / extension.
 * @param {File} file
 * @returns {Promise<string>}
 */
export async function extractTextFromFile(file) {
  const name = file.name.toLowerCase();

  if (name.endsWith(".pdf")) return extractPDF(file);
  if (name.endsWith(".docx") || name.endsWith(".doc")) return extractDOCX(file);
  if (name.endsWith(".pptx") || name.endsWith(".ppt")) return extractPPTX(file);
  if (name.endsWith(".txt")) return extractTXT(file);
  if (name.endsWith(".xml")) return extractXML(file);
  if (name.endsWith(".csv")) return extractCSV(file);

  throw new Error(`Unsupported file type: ${file.name}`);
}

// ── PDF (using pdf.js from CDN loaded in sidebar) ─────────────────────────

async function extractPDF(file) {
  const arrayBuffer = await file.arrayBuffer();
  // pdfjsLib is loaded globally in sidebar.html via CDN script tag
  const pdf = await window.pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  let text = "";
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map((item) => item.str).join(" ") + "\n";
  }
  return text;
}

// ── DOCX (using mammoth.js from CDN) ─────────────────────────────────────

async function extractDOCX(file) {
  const arrayBuffer = await file.arrayBuffer();
  // mammoth is loaded globally in sidebar.html
  const result = await window.mammoth.extractRawText({ arrayBuffer });
  return result.value;
}

// ── PPTX (basic XML extraction — no external lib needed) ─────────────────

async function extractPPTX(file) {
  // PPTX is a ZIP containing XML slides — we use JSZip
  const arrayBuffer = await file.arrayBuffer();
  let text = "";

  try {
    const zip = await window.JSZip.loadAsync(arrayBuffer);
    const slideFiles = Object.keys(zip.files).filter(
      (name) => name.startsWith("ppt/slides/slide") && name.endsWith(".xml")
    );

    for (const slideName of slideFiles.sort()) {
      const xml = await zip.files[slideName].async("string");
      // Extract text nodes from XML
      const parser = new DOMParser();
      const doc = parser.parseFromString(xml, "application/xml");
      const textNodes = doc.querySelectorAll("t");
      text += Array.from(textNodes).map((n) => n.textContent).join(" ") + "\n";
    }
  } catch (e) {
    throw new Error("Could not parse PPTX: " + e.message);
  }

  return text || "No text could be extracted from the presentation.";
}

// ── TXT ───────────────────────────────────────────────────────────────────

async function extractTXT(file) {
  return await file.text();
}

// ── XML ───────────────────────────────────────────────────────────────────

async function extractXML(file) {
  const raw = await file.text();
  const parser = new DOMParser();
  const doc = parser.parseFromString(raw, "application/xml");
  return doc.documentElement.textContent.replace(/\s+/g, " ").trim();
}

// ── CSV ───────────────────────────────────────────────────────────────────

async function extractCSV(file) {
  const text = await file.text();
  return text.slice(0, 5000); // Limit large CSVs
}
