(function () {
  if (window.__neuralMeetInjected) return;
  window.__neuralMeetInjected = true;

  const host = location.hostname;
  const isGoogleMeet = host.includes("meet.google");
  const isZoom = host.includes("zoom.us");
  const isYouTube = host.includes("youtube.com") && location.pathname.includes("/watch");
  const platformName = isGoogleMeet ? "Google Meet" : isZoom ? "Zoom" : isYouTube ? "YouTube" : "Web page";

  const CAPTION_SELECTORS = {
    "Google Meet": ['[jsname="tgaKEf"]', '[data-message-text]', '.a4cQT'],
    Zoom: ['.captions-box', '.captions__sentence', '[aria-label*="caption"]'],
    YouTube: ['.ytp-caption-segment', '.captions-text']
  };

  let isCapturing = false;
  let observer = null;
  let intervalId = null;
  let captionSet = new Set();

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "EXTRACT_PAGE_TEXT") {
      sendResponse(extractPageText());
      return true;
    }

    if (message.type === "START_CAPTURE") {
      startCapture();
      sendResponse({ ok: true });
      return true;
    }

    if (message.type === "STOP_CAPTURE") {
      stopCapture();
      sendResponse({ ok: true });
      return true;
    }
  });

  function extractPageText() {
    const clone = document.body?.cloneNode(true);
    if (!clone) {
      return { text: "", title: document.title || "", url: location.href };
    }

    ["script", "style", "nav", "footer", "header", "aside", "iframe", "noscript"].forEach((tag) => {
      clone.querySelectorAll(tag).forEach((node) => node.remove());
    });

    const text = (clone.innerText || clone.textContent || "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 12000);

    return { text, title: document.title || "", url: location.href };
  }

  function startCapture() {
    if (isCapturing) return;
    isCapturing = true;
    chrome.runtime.sendMessage({ type: "MEETING_STATUS", data: { active: true, platform: platformName } });

    scanCaptions();

    observer = new MutationObserver(() => {
      scanCaptions();
    });

    observer.observe(document.body || document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true
    });

    if (isYouTube) {
      intervalId = window.setInterval(scanTrackCaptions, 1200);
    }
  }

  function stopCapture() {
    if (!isCapturing) return;
    isCapturing = false;
    observer?.disconnect();
    observer = null;
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
    chrome.runtime.sendMessage({ type: "MEETING_STATUS", data: { active: false, platform: platformName } });
  }

  function scanCaptions() {
    const selectors = CAPTION_SELECTORS[platformName] || [];
    selectors.forEach((selector) => {
      document.querySelectorAll(selector).forEach((node) => {
        pushCaption(node.innerText || node.textContent || "");
      });
    });
  }

  function scanTrackCaptions() {
    document.querySelectorAll("video").forEach((video) => {
      const tracks = Array.from(video.textTracks || []);
      tracks.forEach((track) => {
        const cues = Array.from(track.activeCues || []);
        cues.forEach((cue) => pushCaption(cue.text || ""));
      });
    });
  }

  function pushCaption(text) {
    const normalized = String(text || "").replace(/\s+/g, " ").trim();
    if (!normalized || normalized.length < 3 || captionSet.has(normalized)) return;

    captionSet.add(normalized);
    if (captionSet.size > 300) {
      captionSet = new Set(Array.from(captionSet).slice(-150));
    }

    chrome.runtime.sendMessage({
      type: "TRANSCRIPT_UPDATE",
      data: {
        text: normalized,
        time: new Date().toLocaleTimeString()
      }
    });
  }

  function detectAutoStart() {
    if (isGoogleMeet || isZoom) {
      return true;
    }
    if (isYouTube && document.querySelector("video")) {
      return true;
    }
    return false;
  }

  if (detectAutoStart()) {
    setTimeout(startCapture, 2500);
  }
})();
