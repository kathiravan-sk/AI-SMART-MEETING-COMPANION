# NeuralMeet Workspace

NeuralMeet Workspace is a Chrome extension for three core jobs:

1. Capture captions from live meeting and video tabs.
2. Upload audio or video files and transcribe them into text.
3. Automatically summarize transcripts into clear notes, decisions, and action items.

## Project model

```text
extension/
|-- manifest.json         Chrome extension manifest
|-- background.js         Side panel launcher, AI relay, media transcription relay
|-- content.js            Page extraction, caption detection, meeting/video capture
|-- sidebar.html          Main workspace UI
|-- sidebar.css           User-friendly interface styling
|-- sidebar.js            Main application logic for meetings, media, docs, chat, notes
|-- ai/
|   `-- api.js            Prompt builders and AI request helper
|-- fileHandler/
|   `-- index.js          Client-side document text extraction
|-- offlineAI/
|   |-- chunking.js       Text chunking utilities
|   |-- search.js         Offline retrieval and summary helpers
|   `-- storage.js        IndexedDB storage wrapper
|-- lib/                  PDF, DOCX, and PPTX parsing libraries
`-- icons/                Extension icons
```

## Main workflows

### 1. Live meeting capture

- Open Google Meet, Zoom web, or a captioned YouTube/video page.
- Open the extension side panel.
- Go to the `Meetings` tab and click `Start capture` if it does not start automatically.
- Captions are collected into the transcript stream.
- Summaries are generated automatically when enough transcript is available.

### 2. Audio and video transcription

- Open the `Media` tab.
- Upload an audio or video file.
- The extension sends the file to OpenAI transcription if an API key is configured.
- The returned text is shown in the transcript area and summarized automatically.
- You can save the transcript into the document library.

### 3. Document workspace

- Upload PDF, DOCX, PPTX, TXT, XML, or CSV files in `Documents`.
- Summarize or search the selected document.
- Reuse document context in `Ask AI`.

## Settings

The extension stores provider settings locally in the browser:

- `Provider`
- `API key`
- `Chat model`
- `Transcription model`
- `Auto summary`

## Notes

- Meeting capture depends on captions or on-screen transcript text being available in the page.
- Media transcription currently uses OpenAI in the background worker.
- Files larger than 25 MB should be trimmed before upload for transcription.
